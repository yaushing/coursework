def add(first_number, second_number):
    total = first_number + second_number
    print(first_number, "+", second_number, "=", total)

add(5, 7)
add(2012, 137)
add(1234, 4321)

